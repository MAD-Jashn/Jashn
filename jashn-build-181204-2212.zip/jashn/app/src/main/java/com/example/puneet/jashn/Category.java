package com.example.puneet.jashn;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.Locale;

public class  Category implements Serializable,Parcelable{
    private String date;
    private String eventName;
    private String eventDetail;
    private String eventID;


    public Category(){

    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public static Creator<Category> getCREATOR() {
        return CREATOR;
    }

    public Category(String date, String eventName, String eventDetail, String eventID) {
        this.date = date;
        this.eventName = eventName;
        this.eventDetail = eventDetail;
        this.eventID = eventID;
    }

    protected Category(Parcel in) {
        date = in.readString();
        eventName = in.readString();
        eventDetail = in.readString();
    }

    public static final Creator<Category> CREATOR = new Creator<Category>() {
        @Override
        public Category createFromParcel(Parcel in) {
            return new Category(in);
        }

        @Override
        public Category[] newArray(int size) {
            return new Category[size];
        }
    };

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDetail() {
        return eventDetail;
    }

    public void setEventDetail(String eventDetail) {
        this.eventDetail = eventDetail;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(date);
        dest.writeString(eventName);
        dest.writeString(eventDetail);
    }
}
