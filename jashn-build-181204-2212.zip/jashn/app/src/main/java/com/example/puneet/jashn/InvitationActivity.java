package com.example.puneet.jashn;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Ref;
import java.util.HashMap;
import java.util.Map;

public class InvitationActivity extends AppCompatActivity {

    private String date;
    private String time;
    private String venue;
    private String guests;
    private String description;
    TextView eDate, eTime, eVenue, eGuests, eDescription,eMinAge,eFees;
    TextView eDateVal, eTimeVal, eVenueVal, eGuestsVal, eThemeVal,eMinAgeVal,eFeesVal;
    Button bAccept,bDecline;
    DatabaseReference mFirebaseDatabase;
    FirebaseAuth mAuth;
    DatabaseReference ref,ref2;
    FirebaseAuth.AuthStateListener mAuthListener;
    final String TAG = "InvitationActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitation);

        eDate = findViewById(R.id.dateView);
        eTime = findViewById(R.id.timeView);
        eVenue = findViewById(R.id.venueView);
        eGuests = findViewById(R.id.guestsView);
        eDescription = findViewById(R.id.descView);
        eMinAge = findViewById(R.id.minAgeView);
        eFees = findViewById(R.id.feesView);
        bAccept = findViewById(R.id.acceptButton);
        bDecline = findViewById(R.id.declineButton);
        eDateVal = findViewById(R.id.dateValue);
        eTimeVal = findViewById(R.id.timeValue);
        eVenueVal = findViewById(R.id.venueValue);
        eGuestsVal = findViewById(R.id.guestsValue);
        eThemeVal = findViewById(R.id.themeValue);
        eMinAgeVal = findViewById(R.id.minAgeViewValue);
        eFeesVal = findViewById(R.id.feesViewValue);
        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance().getReference();
        FirebaseUser user = mAuth.getCurrentUser();
        final String userID = user.getUid();
        ref = mFirebaseDatabase.child("events");
//        DatabaseReference eventRef = ref.child("events");
//        DatabaseReference profileRef = ref.child("profiles");
        final String eventID = getIntent().getStringExtra("event_id");
        Log.d(TAG, "onCreate: eventID "+eventID);

// Attach a listener to read the data at your profile reference
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //Event event = dataSnapshot.getValue(Event.class);
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    Log.d(TAG, "onDataChangeds: " + ds);
                    Event event = new Event();
                    String eid = ds.child("eventID").getValue(String.class);
                    Log.d(TAG, "onDataChange: eid " + eid);
                    if (eid.equals(eventID)) {
                        Log.d(TAG, "onDataChange: eid " + eid);

                        Invitation invite = new Invitation();
                        invite.setDate(ds.child("date").getValue(String.class));
                        invite.setTime(ds.child("time").getValue(String.class));
                        invite.setDescription(ds.child("description").getValue(String.class));
                        invite.setGuests(ds.child("guests").getValue(String.class));
                        invite.setVenue(ds.child("location").getValue(String.class));
                        invite.setFees(ds.child("entryFee").getValue(String.class));
                        invite.setMinAge(ds.child("minAge").getValue(String.class));
                        eDateVal.setText(ds.child("date").getValue(String.class));
                        Log.d(TAG, "onDataChange: dfssdf" + event.getDate());
                        eTimeVal.setText(ds.child("time").getValue(String.class));
                        eVenueVal.setText(ds.child("location").getValue(String.class));
                        eGuestsVal.setText(ds.child("guests").getValue(String.class));
                        eDescription.setText(ds.child("description").getValue(String.class));
                        try {
                            eMinAgeVal.setText(ds.child("minAge").getValue(String.class));
                            eFeesVal.setText(ds.child("entryFee").getValue(String.class));
                        }
                        catch (DatabaseException databaseException) {
                            eMinAgeVal.setText(0);
                            eFeesVal.setText(0);
                        }

                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });
        Invitation invite = new Invitation();
        ref2 = mFirebaseDatabase.child("profiles");
        if(!invite.getAccept()){
            bAccept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Invitation invite = new Invitation();
                    Event event = new Event();
                    invite.setAccept(true);
                    ref2.child(userID).child("acceptedEvent").push().setValue(eventID);//getEventID karni hai
                    Toast.makeText(InvitationActivity.this, "Event Accepted", Toast.LENGTH_SHORT).show();
                    bAccept.setText("Accepted");
                }
            });
        }else {
            bAccept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getApplicationContext(),"Event Already Accepted",Toast.LENGTH_SHORT).show();
                }
            });
        }

        bDecline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InvitationActivity.this,EventLandingActivity.class);
                startActivity(intent);
            }
        });

    }

}