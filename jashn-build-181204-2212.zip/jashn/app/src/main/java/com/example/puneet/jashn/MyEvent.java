package com.example.puneet.jashn;

public class MyEvent {
    private String id;
    private String eventID;
    private String profileID;
    private String time;
    private String title;
    private String category;
    private String host;
    private String date;
    private String description;

    public MyEvent(){
    }

    public MyEvent(String id, String eventID, String profileID, String time, String title, String category, String host,String date,String description) {
        this.id = id;
        this.eventID = eventID;
        this.profileID = profileID;
        this.time = time;
        this.title = title;
        this.category = category;
        this.host = host;
        this.date = date;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getProfileID() {
        return profileID;
    }

    public void setProfileID(String profileID) {
        this.profileID = profileID;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
