package com.example.puneet.jashn;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CategoryActivity extends AppCompatActivity implements Serializable {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    CategoryAdapter adapter;
    private RecyclerView.LayoutManager mLayoutManager;
    final String TAG = "SearchActivity";


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mRecyclerView = findViewById(R.id.recycler_view);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);


        Bundle b = this.getIntent().getExtras();
        ArrayList<Category> myList = b.getParcelableArrayList("categoryList");
//        Bundle args = intent.getBundleExtra("BUNDLE");
//        ArrayList<Category> myList =((ArrayList<Category>)args.getSerializable("categoryList"));
////        myList = (ArrayList<Category>) getIntent().getSerializableExtra("categoryList");
        Log.d(TAG, "onCreate: puneet1" + myList.size());
        adapter = new CategoryAdapter(myList,this);
        mRecyclerView.setAdapter(adapter);
    }


}
